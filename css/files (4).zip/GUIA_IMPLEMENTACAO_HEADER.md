# 📘 GUIA DE IMPLEMENTAÇÃO - HEADER AUTOMÁTICO

**Sistema de Header Reutilizável com Opção 1 (App + Subtítulo)**

---

## 📦 ARQUIVOS CRIADOS

1. ✅ `header-loader.js` - Script que cria header automaticamente
2. ✅ `header-component.css` - Estilos do header
3. ✅ `design-tokens-v3.css` - Cores com dark mode completo

---

## 🚀 PASSO A PASSO

### **1. Adicionar os arquivos CSS e JS no projeto**

Coloque os arquivos nas pastas corretas:

```
VISA/
├── css/
│   ├── design-tokens.css        ← Substituir pelo design-tokens-v3.css
│   └── components.css            ← Adicionar conteúdo de header-component.css
├── js/
│   ├── platform-detector.js      ← Já existe
│   └── header-loader.js          ← NOVO arquivo
```

---

### **2. Atualizar components.css**

**Opção A:** Substituir arquivo inteiro  
**Opção B:** Adicionar no FINAL do `components.css` existente:

```css
/* Cole aqui o conteúdo de header-component.css */
```

---

### **3. Aplicar em CADA página HTML**

#### **PÁGINA PRINCIPAL (index.html):**

```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <link rel="stylesheet" href="./css/design-tokens.css">
  <link rel="stylesheet" href="./css/base.css">
  <link rel="stylesheet" href="./css/components.css">
  <link rel="stylesheet" href="./css/layouts.css">
  
  <script src="./js/platform-detector.js"></script>
  <script src="./js/header-loader.js"></script> <!-- NOVO -->
  
  <title>Vigilância Sanitária</title>
</head>

<body>
  <!-- HEADER AUTOMÁTICO -->
  <div id="app-header"></div>
  
  <!-- RESTO DO CONTEÚDO -->
  <div class="container">
    <!-- ... seu conteúdo ... -->
  </div>
</body>
</html>
```

#### **PÁGINAS SECUNDÁRIAS (legislacao.html, Regulados.html, etc):**

```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <link rel="stylesheet" href="./css/design-tokens.css">
  <link rel="stylesheet" href="./css/base.css">
  <link rel="stylesheet" href="./css/components.css">
  <link rel="stylesheet" href="./css/layouts.css">
  
  <script src="./js/platform-detector.js"></script>
  <script src="./js/header-loader.js"></script>
  
  <title>Legislação Sanitária</title>
</head>

<body>
  <!-- HEADER AUTOMÁTICO com VOLTAR -->
  <div id="app-header" data-back-url="./index.html"></div>
  
  <!-- CONTEÚDO -->
  <div class="container">
    <!-- ... links de legislação ... -->
  </div>
</body>
</html>
```

#### **PÁGINAS DENTRO DE PASTAS (check-list-drogarias-1/index.html):**

```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <link rel="stylesheet" href="../css/design-tokens.css">
  <link rel="stylesheet" href="../css/base.css">
  <link rel="stylesheet" href="../css/components.css">
  <link rel="stylesheet" href="../css/layouts.css">
  
  <script src="../js/platform-detector.js"></script>
  <script src="../js/header-loader.js"></script>
  
  <title>Check List - Drogarias</title>
</head>

<body>
  <!-- HEADER AUTOMÁTICO voltando para check.html -->
  <div id="app-header" data-back-url="../check.html"></div>
  
  <!-- CHECKLIST -->
  <div class="container">
    <!-- ... checklist ... -->
  </div>
</body>
</html>
```

---

## 🎯 ATRIBUTOS DO CONTAINER

### **`data-back-url`** (obrigatório em páginas secundárias)

Define para onde o botão "Voltar" vai:

```html
<!-- Volta para index.html -->
<div id="app-header" data-back-url="./index.html"></div>

<!-- Volta para check.html (um nível acima) -->
<div id="app-header" data-back-url="../check.html"></div>

<!-- Volta para página específica -->
<div id="app-header" data-back-url="./Regulados.html"></div>
```

### **`data-page-title`** (opcional)

Sobrescreve título automático:

```html
<div id="app-header" 
     data-back-url="./index.html"
     data-page-title="Legislação Sanitária"></div>
```

Se não informar, o script pega do `<title>` automaticamente.

---

## 📋 MAPA DE NAVEGAÇÃO

### **Estrutura Completa:**

```
index.html
  ↓ (sem data-back-url)
  
legislacao.html
  ↓ data-back-url="./index.html"
  
Regulados.html
  ↓ data-back-url="./index.html"
  
check.html
  ↓ data-back-url="./index.html"
  ├─ check-list-alimentos-geral/index.html
  │    ↓ data-back-url="../check.html"
  │
  ├─ check-list-drogarias-1/index.html
  │    ↓ data-back-url="../check.html"
  │
  ├─ check-list-acougue/index.html
  │    ↓ data-back-url="../check.html"
  │
  └─ check-list-escola/index.html
       ↓ data-back-url="../check.html"
```

---

## 🎨 RESULTADO VISUAL

### **Desktop:**

```
┌─────────────────────────────────────────────┐
│                                             │
│         Vigilância Sanitária                │
│    📜 Legislação Sanitária                  │
│                                             │
└─────────────────────────────────────────────┘
```

### **Mobile:**

```
┌─────────────────────────────────────────────┐
│ ‹ Voltar                             OK ✓   │
│                                             │
│         Vigilância Sanitária                │
│    📜 Legislação Sanitária                  │
│                                             │
└─────────────────────────────────────────────┘
```

---

## ✅ CHECKLIST DE IMPLEMENTAÇÃO

### **Fase 1: Preparação**
- [ ] Substituir `css/design-tokens.css` por `design-tokens-v3.css`
- [ ] Adicionar conteúdo de `header-component.css` em `css/components.css`
- [ ] Adicionar `js/header-loader.js` no projeto

### **Fase 2: Página Principal**
- [ ] Remover `<header>` antigo do `index.html`
- [ ] Adicionar `<div id="app-header"></div>`
- [ ] Adicionar `<script src="./js/header-loader.js"></script>`
- [ ] Testar se header aparece corretamente

### **Fase 3: Páginas Raiz (legislacao, Regulados, check, etc)**
- [ ] legislacao.html → `data-back-url="./index.html"`
- [ ] Regulados.html → `data-back-url="./index.html"`
- [ ] check.html → `data-back-url="./index.html"`
- [ ] Escala_Ferias_Janeiro_2026_APP.html → `data-back-url="./index.html"`
- [ ] Escala_Veiculos_Janeiro_2026_APP.html → `data-back-url="./index.html"`
- [ ] Escala_Plantao_Janeiro_2026.html → `data-back-url="./index.html"`
- [ ] relatorio_plantao_fiscal.html → `data-back-url="./index.html"`
- [ ] cadastro_economico_por_equipe_colorido.html → `data-back-url="./index.html"`

### **Fase 4: Checklists (dentro de pastas)**
- [ ] check-list-alimentos-geral/index.html → `data-back-url="../check.html"`
- [ ] check-list-drogarias-1/index.html → `data-back-url="../check.html"`
- [ ] check-list-acougue/index.html → `data-back-url="../check.html"`
- [ ] check-list-escola/index.html → `data-back-url="../check.html"`
- [ ] check-list-varejista-cosme-e-san/index.html → `data-back-url="../check.html"`
- [ ] check-list-saude-cnaes-8630502-e-8630503/index.html → `data-back-url="../check.html"`
- [ ] checklist-academia/index.html → `data-back-url="../check.html"`

### **Fase 5: Testes**
- [ ] Testar index.html (não deve ter botão voltar)
- [ ] Testar legislacao.html (deve voltar para index)
- [ ] Testar check.html (deve voltar para index)
- [ ] Testar check-list-drogarias-1/index.html (deve voltar para check)
- [ ] Testar dark mode Android
- [ ] Testar dark mode iOS
- [ ] Testar botões mobile (aparecem < 768px)
- [ ] Testar botões desktop (não aparecem > 768px)

---

## 🐛 TROUBLESHOOTING

### **Header não aparece:**
✅ Verificar se `<div id="app-header"></div>` existe  
✅ Verificar se `header-loader.js` está carregando  
✅ Abrir Console (F12) e procurar erros  

### **Botão Voltar não funciona:**
✅ Verificar se `data-back-url` está correto  
✅ Verificar caminho relativo (`./` vs `../`)  

### **Título errado:**
✅ Mudar o `<title>` da página  
✅ Ou usar `data-page-title="Título Correto"`  

### **Cores erradas no dark mode:**
✅ Limpar cache do navegador  
✅ Verificar se `design-tokens-v3.css` foi aplicado  
✅ Verificar se `platform-detector.js` está rodando  

---

## 📊 ANTES vs DEPOIS

### **ANTES:**
```html
<!-- 30+ linhas de HTML repetido em cada página -->
<header>
  <h1>Vigilância Sanitária</h1>
  <h2>Diretoria...</h2>
  <!-- CSS inline -->
  <style>...</style>
</header>
```

### **DEPOIS:**
```html
<!-- 1 linha! -->
<div id="app-header" data-back-url="./index.html"></div>
```

**Benefícios:**
- ✅ 97% menos código por página
- ✅ Muda 1 arquivo CSS → atualiza TODAS as páginas
- ✅ Header consistente automaticamente
- ✅ Botão voltar automático
- ✅ Dark mode funcional

---

## 🎯 PRÓXIMOS PASSOS

1. **Teste em 1 página** primeiro (legislacao.html)
2. **Se funcionar**, aplique nas outras
3. **Teste mobile** (Android e iOS)
4. **Teste dark mode**
5. **Pronto!** 🎉

---

**Criado por:** Claude  
**Data:** 01/01/2026  
**Versão:** 1.0
